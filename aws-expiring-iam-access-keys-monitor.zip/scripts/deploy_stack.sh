#!/bin/bash
STACK_NAME="IAMKeyExpiryMonitor"
TEMPLATE_FILE="cloudformation/expiring-keys-monitor.yaml"
REGION="${AWS_REGION:-us-gov-west-1}"
PARAM_BUCKET="${CONFIG_BUCKET}"

aws cloudformation deploy --stack-name $STACK_NAME --template-file $TEMPLATE_FILE --region $REGION --parameter-overrides ConfigBucket=$PARAM_BUCKET --capabilities CAPABILITY_NAMED_IAM