# IAM Access Key Expiry Monitor (Generic, GovCloud-Compatible)

This project monitors AWS IAM access keys and sends alerts for keys older than a configurable threshold. It is generic, supports multiple accounts, and works in AWS GovCloud.